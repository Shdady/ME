// JavaScript لصفحة الإذاعة

document.addEventListener('DOMContentLoaded', function() {
    // تبديل القائمة المتنقلة للأجهزة المحمولة
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // تنفيذ مشغل YouTube Live
    const placeholder = document.querySelector('.placeholder');
    const playerContainer = document.querySelector('.youtube-player');
    const listenBtn = document.querySelector('.listen-btn');
    
    // وظيفة لإنشاء مشغل YouTube
    function createYouTubePlayer() {
        // إزالة العنصر البديل
        if (placeholder) {
            placeholder.remove();
        }
        
        // إنشاء عنصر iframe لمشغل YouTube
        const iframe = document.createElement('iframe');
        iframe.width = '100%';
        iframe.height = '100%';
        iframe.src = 'https://www.youtube.com/embed/live_stream?channel=CHANNEL_ID&autoplay=1';
        iframe.frameBorder = '0';
        iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
        iframe.allowFullscreen = true;
        iframe.style.position = 'absolute';
        iframe.style.top = '0';
        iframe.style.left = '0';
        
        // إضافة iframe إلى حاوية المشغل
        playerContainer.appendChild(iframe);
    }
    
    // تشغيل البث عند النقر على العنصر البديل أو زر الاستماع
    if (placeholder) {
        placeholder.addEventListener('click', createYouTubePlayer);
    }
    
    if (listenBtn) {
        listenBtn.addEventListener('click', createYouTubePlayer);
    }
    
    // تحديث معلومات البرنامج الحالي
    function updateCurrentProgram() {
        const currentProgramElement = document.querySelector('.current-program h3');
        const currentTimeElement = document.querySelector('.current-program .time');
        
        if (currentProgramElement && currentTimeElement) {
            const now = new Date();
            const hours = now.getHours();
            
            // تحديد البرنامج الحالي بناءً على الوقت
            let currentProgram = '';
            let programTime = '';
            
            if (hours >= 10 && hours < 12) {
                currentProgram = 'البرنامج الحالي: التوعية والإرشاد';
                programTime = 'من الساعة 10:00 إلى 12:00';
            } else if (hours >= 12 && hours < 14) {
                currentProgram = 'البرنامج الحالي: نشرة الأخبار';
                programTime = 'من الساعة 12:00 إلى 14:00';
            } else if (hours >= 14 && hours < 16) {
                currentProgram = 'البرنامج الحالي: حوارات ثقافية';
                programTime = 'من الساعة 14:00 إلى 16:00';
            } else if (hours >= 16 && hours < 18) {
                currentProgram = 'البرنامج الحالي: موسيقى سودانية';
                programTime = 'من الساعة 16:00 إلى 18:00';
            } else if (hours >= 18 && hours < 20) {
                currentProgram = 'البرنامج الحالي: برامج تعليمية';
                programTime = 'من الساعة 18:00 إلى 20:00';
            } else if (hours >= 20 && hours < 22) {
                currentProgram = 'البرنامج الحالي: تمكين المرأة';
                programTime = 'من الساعة 20:00 إلى 22:00';
            } else {
                currentProgram = 'البرنامج الحالي: منوعات';
                programTime = 'برامج متنوعة';
            }
            
            currentProgramElement.textContent = currentProgram;
            currentTimeElement.textContent = programTime;
        }
    }
    
    // تحديث معلومات البرنامج عند تحميل الصفحة
    updateCurrentProgram();
    
    // تحديث معلومات البرنامج كل دقيقة
    setInterval(updateCurrentProgram, 60000);
    
    // معالجة نموذج الاتصال
    const contactForm = document.querySelector('.contact-form form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // هنا يمكن إضافة رمز لإرسال النموذج إلى الخادم
            alert('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.');
            contactForm.reset();
        });
    }
    
    // معالجة نموذج الاشتراك في النشرة البريدية
    const subscribeForm = document.querySelector('.subscribe-form');
    
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // هنا يمكن إضافة رمز لإرسال النموذج إلى الخادم
            alert('تم الاشتراك في النشرة البريدية بنجاح!');
            subscribeForm.reset();
        });
    }
});

// وظيفة لتحديث مشغل YouTube Live بمعرف القناة الفعلي
function updateYouTubeChannelId(channelId) {
    const iframe = document.querySelector('.youtube-player iframe');
    
    if (iframe) {
        iframe.src = `https://www.youtube.com/embed/live_stream?channel=${channelId}&autoplay=1`;
    }
}

// ملاحظة: يجب استبدال "CHANNEL_ID" بمعرف قناة YouTube الفعلي عند إنشاء القناة
